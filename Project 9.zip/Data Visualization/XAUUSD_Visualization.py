import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os

class CloseXAUUSDAnalyzer:
    def __init__(self):
        """Constructor for initialization the DataFrame and show welcome screen."""
        
        self.data = None  
        self.current_fig = None
        print("\n" + "="*60)
        print("   --- XAUUSD (GOLD) DATA ANALYZER SYSTEM ---   ")
        print("="*60)

    def load_data(self, file_path):
        """Load data from a CSV file into a DataFrame."""
        
        try:
            
            if os.path.exists(file_path) and file_path.endswith('.csv'):
                self.data = pd.read_csv(file_path)
                print(f"--- Success: Dataset loaded! Records: {len(self.data)}")
                
            else:
                print("--- Error: Invalid file path or not a CSV file.")
                
        except Exception as e:
            print(f"--- Critical Error: {e}")

    def explore_data(self):
        """Detailed exploration of the dataset."""
        
        try:
            while True:
                if self.data is not None:
                    
                    print("\n" + "="*20 + " EXPLORE DATA MENU " + "="*20)
                    print("1. View Top 5 Records")
                    print("2. View Bottom 5 Records")
                    print("3. List All Column Names")
                    print("4. Check Data Types of Columns")
                    print("5. View Full Dataset Summary")
                    print("6. Show Number of Rows and Columns")
                    print("7. Return to Main Menu")
                    
                    ch = input("\nSelect Sub-Option (1-7): ")

                    print("-" * 50)
                    if ch == '1': 
                        print(f"Top 5 Records:\n{self.data.head().to_string()}")
                        
                    elif ch == '2': 
                        print(f"Bottom 5 Records:\n{self.data.tail().to_string()}")
                        
                    elif ch == '3': 
                        print(f"Columns in Dataset: \n{self.data.columns.tolist()}")
                        
                    elif ch == '4': 
                        print(f"Data Types: \n{self.data.dtypes}")
                        
                    elif ch == '5': 
                        print(self.data.info())
                        
                    elif ch == '6':
                        print(f"Dataset Dimensions: {self.data.shape[0]} Rows, {self.data.shape[1]} Columns")
                        
                    elif ch == '7': 
                        break
                    
                    else:
                        print("Invalid selection. Please try again.")
                        
                else:
                    print("\nAccess Denied: Dataset not loaded. Please use Option 1 first.")
                    break
                
        except Exception as e:
            print(f"\nExploration Error: {e}")

    def clean_data(self):
        """Comprehensive data cleaning and missing value management."""
        try:
            while True:
                if self.data is not None:
                    
                    print("\n" + "="*20 + " DATA CLEANING " + "="*20)
                    print(f"Current Null Values Count:\n{self.data.isnull().sum()}")
                    print("-" * 50)
                    print("1. Display only rows with missing values")
                    print("2. Fill missing numeric values with Column Mean")
                    print("3. Drop all rows containing any missing value")
                    print("4. Replace NULLs with a custom value (Manual)")
                    print("5. Return to Main Menu")
                    
                    ch = input("\nAction Choice (1-5): ")
                    
                    if ch == '1':
                        missing_rows = self.data[self.data.isnull().any(axis=1)]
                        print(f"Rows with Missing Values:\n{missing_rows.to_string()}" if not missing_rows.empty else "No missing values found!")

                    elif ch == '2':
                        self.data.fillna(self.data.mean(numeric_only=True), inplace=True)
                        print("Process Complete: Numeric columns filled with mean.")

                    elif ch == '3':
                        self.data.dropna(inplace=True)
                        print("Process Complete: Rows with null values removed.")
                        print(f"Remaining Records: {self.data.shape[0]}")

                    elif ch == '4':
                        val = input("Enter replacement value: ")
                        self.data.fillna(val, inplace=True)
                        print(f"Process Complete: Nulls replaced with '{val}'.")

                    elif ch == '5':
                        break
                else:
                    print("\nAccess Denied: Load data first.")
                    break
        except Exception as e:
            print(f"\nCleaning Error: {e}")

    def dataframe_operations(self):
        """Mathematical operations using NumPy arrays for performance."""
        if self.data is not None:
            print("\n" + "="*15 + " Perform DataFrame Operations " + "="*15)

            if 'Close' in self.data.columns:
                Close_array = np.array(self.data['Close'])
                
                print(f"Basic Array View: {Close_array[:5]} ...")
                print(f"Total Sum of Close: {np.nansum(Close_array):,.2f}")
                print(f"Highest Close Price: {np.nanmax(Close_array)}")
                print(f"Lowest Close Price: {np.nanmin(Close_array)}")
                print(f"Statistical Standard Deviation: {np.nanstd(Close_array):.2f}")
                print(f"Statistical Variance: {np.nanvar(Close_array):.2f}")
                print(f"Array Slicing (Data from index 5 to 15):")
                print(Close_array[5:15])
                
            else:
                print("Error: 'Close' column not found in this dataset.")
                
        else:
            print("\nAccess Denied: Load data first.")

    def search_sort_filter(self):
        """Data manipulation through sorting and filtering."""
        try:
            while True:
                if self.data is not None:
                    
                    print("\n" + "="*15 + " SEARCH, SORT & FILTER " + "="*15)
                    print("1. Sort Dataset by Close (Higher to Lower)")
                    print("2. Filter Records by a Specific UTC Timestamp")
                    print("3. Search by Time Keyword (UTC Column)")
                    print("4. Back to Main Menu")
                    
                    ch = input("\nSelect Action: ")

                    if ch == '1':
                        print(self.data.sort_values(by='Close', ascending=False).head(15))

                    elif ch == '2':
                        utc_input = input("Enter exact UTC string (e.g. 13.03.2026 00:00:00.000 UTC): ")
                        result = self.data[self.data['UTC'].str.contains(utc_input, case=False, na=False)]
                        print(result if not result.empty else "No records found for this UTC.")

                    elif ch == '3':
                        keyword = input("Enter Time/Date Keyword: ")
                        result = self.data[self.data['UTC'].str.contains(keyword, case=False, na=False)]
                        print(result if not result.empty else "No matching records found.")

                    elif ch == '4':
                        break
                    
                else:
                    print("\nAccess Denied: Load data first.")
                    break
                
        except Exception as e:
            print(f"\nSearch/Sort Error: {e}")

    def visualize_data(self):
        """Advanced Data Visualization using Seaborn and Matplotlib."""
        try:
            while True:
                if self.data is not None:
                    
                    print("\n" + "="*20 + " VISUALIZATION ENGINE " + "="*20)
                    print("1. Bar Plot (Volume of first 10 records)")
                    print("2. Line Plot (Close Price Trends)")
                    print("3. Scatter Plot (Open vs Close Price)")
                    print("4. Pie Chart (Volume Share of Top 5 records)")
                    print("5. Histogram (Distribution of Close Price)")
                    print("6. Box Plot (Close Price Variation)")
                    print("7. Back to Main Menu")
                    
                    ch = input("\nEnter Chart Type (1-7): ")
                    if ch == '7':
                        break
                    
                    if ch not in ['1', '2', '3', '4', '5', '6']:
                        print("Invalid selection. Please try again.")
                        continue

                    fig=plt.figure(figsize=(12 ,7))
                    self.current_fig = fig
                    sns.set_style("whitegrid")
                    
                    if ch == '1':
                        self.data.head(10).plot(x='UTC', y='Volume', kind='bar', color='teal', ax=plt.gca())
                        plt.title("Volume Analysis (First 10 Records)")
                        plt.xticks(rotation=45)

                    elif ch == '2':
                        plt.plot(self.data['Close'], marker='.', color='orange', linewidth=1)
                        plt.title("XAUUSD Close Price Trend")

                    elif ch == '3':
                        sns.regplot(x='Open', y='Close', data=self.data, scatter_kws={'alpha':0.5})
                        plt.title("Correlation: Open vs Close Price")
                    
                    elif ch == '4':
                        self.data.head(5).set_index('UTC')['Volume'].plot(kind='pie', autopct='%1.2f%%', shadow=True)
                        plt.ylabel('')
                        plt.title("Volume Contribution (Top 5 Records)")
                    
                    elif ch == '5':
                        sns.histplot(self.data['Close'], bins=15, kde=True, color='purple')
                        plt.title("Price Distribution (Close)")
                    
                    elif ch == '6':
                        sns.boxplot(y=self.data['Close'], color='lightgreen')
                        plt.title("Close Price Range and Outliers")

                    plt.tight_layout()
                    
                    save = input("\nConfirm: Save this visualization as PNG? (y/n): ")
                    if save.lower() == 'y':
                        fname = input("Enter Filename: ")
                        plt.savefig(fname if fname.endswith('.png') else fname + '.png')
                        print(f"Successfully saved as {fname}")
                    
                    print("Plot is generated and kept in memory.")
                    plt.show() 

                else:
                    print("\nError: No data available to visualize.")
                    break
                
        except Exception as e:
            print(f"\nPlotting Error: {e}")

    def save_current_plot(self):
        """Saves the last generated plot to a file using the stored figure object."""
        try:
           
            if self.current_fig is not None:
                fname = input("Enter Filename to save (e.g., my_chart.png): ")
                
                if not fname.strip():
                    fname = "last_plot.png"
                elif not fname.lower().endswith('.png'):
                    fname += '.png'
                
                self.current_fig.savefig(fname)
                print(f"--- Success: Plot saved as {fname} ---")
                
            else:
                print("\nError: No plot found in memory!")
                print("Hint: First generate a chart using Option 6.")
                
        except Exception as e:
            print(f"Error while saving plot: {e}")
            
def main():
    analyzer = CloseXAUUSDAnalyzer()
    
    try:
        while True:
            
            print("\n" + "="*20 + " MAIN CONTROL PANEL " + "="*20)
            print("1. Load Dataset (CSV)")
            print("2. Explore Data (Head, Tail, Info)")
            print("3. Perform Mathematical Operations (NumPy)")
            print("4. Handle Nulls & Clean Data")
            print("5. Search, Sort and Filter Data")
            print("6. Generate Visualizations (Bar, Line, Scatter, etc.)")
            print("7. Save Last Generated Visualization")
            print("8. Exit")
            
            choice = input("\nEnter your Choice (1-8): ")
            
            if choice == '1':
                path = input("Enter filename (e.g., XAUUSD.csv): ")
                analyzer.load_data(path)
                
            elif choice == '2':
                analyzer.explore_data()
                
            elif choice == '3':
                analyzer.dataframe_operations()
                
            elif choice == '4':
                analyzer.clean_data()
                
            elif choice == '5':
                analyzer.search_sort_filter()
                
            elif choice == '6':
                analyzer.visualize_data()
                
            elif choice == '7':
                analyzer.save_current_plot()
                
            elif choice == '8':
                print("\nShutting down system. Goodbye!")
                break
            
            else:
                print("\nInvalid Selection: Please choose between 1 and 8.")
                
    except Exception as e:
            print(f"\nSystem Error: {e}")

if __name__ == "__main__":
    main()