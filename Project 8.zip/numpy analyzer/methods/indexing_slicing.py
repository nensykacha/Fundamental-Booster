import numpy as np
def indexing_slicing(array):
    """function to demostrate indexing and slicing operations on a array"""
    while True:
        try:   
            print("\n1. Indexing array")
            print("2. Slicing array")
            print("3. Back To Main Menue")

            choice = int(input("Enter your choice (1-3): "))

            if choice == 1:
                print("\nIndexing Operation")
               #For 1D array
                if array.ndim == 1:
                    index = int(input("Enter the index to access: "))
                    if 0 <= index < len(array):
                       print(f"\nElement at index {index} : {array[index]}\n")
                    else:
                        print("Index out of bounds.")   
                 
                #For 2D array
                elif array.ndim == 2:
                    row = int(input("Enter the row index: "))
                    col = int(input("Enter the column index: "))
                    if 0 <= row < array.shape[0] and 0 <= col < array.shape[1]:
                            print(f"\nElement at [{row}, {col}] : {array[row, col]}\n")
                    else:
                            print("Row or column index out of bounds.")
                            
                #For 3D array
                elif array.ndim == 3:
                    depth = int(input("Enter the depth index: "))
                    row = int(input("Enter the row index: "))
                    col = int(input("Enter the column index: "))
                    if (0 <= depth < array.shape[0] and 
                        0 <= row < array.shape[1] and 
                        0 <= col < array.shape[2]):
                            print(f"\nElement at [{depth}, {row}, {col}] : {array[depth, row, col]}\n")
                    else:
                            print("Depth, row, or column index out of bounds.")
                                 
            elif choice == 2:
                print("\nSlicing Operation")
                #For 1D array
                if array.ndim == 1:
                    start = int(input("Enter the start index: "))
                    end = int(input("Enter the end index: "))
                    if 0 <= start < len(array) and 0 <= end <= len(array) and start < end:
                        print(f"\nSliced array: {array[start:end]}\n")
                    else:
                        print("Invalid start or end index.")
                        
                #For 2D array
                elif array.ndim == 2:
                    row_start = int(input("Enter the start row index: "))
                    row_end = int(input("Enter the end row index: "))
                    col_start = int(input("Enter the start column index: "))
                    col_end = int(input("Enter the end column index: "))
                    if (0 <= row_start < array.shape[0] and 
                        0 <= row_end <= array.shape[0] and 
                        0 <= col_start < array.shape[1] and 
                        0 <= col_end <= array.shape[1] and 
                        row_start < row_end and 
                        col_start < col_end):
                            print(f"\nSliced array:\n{array[row_start:row_end, col_start:col_end]}\n")
                    else:
                            print("Invalid row or column indices.")
                            
                #For 3D array
                elif array.ndim == 3:
                    depth_start = int(input("Enter the start depth index: "))
                    depth_end = int(input("Enter the end depth index: "))
                    row_start = int(input("Enter the start row index: "))
                    row_end = int(input("Enter the end row index: "))
                    col_start = int(input("Enter the start column index: "))
                    col_end = int(input("Enter the end column index: "))
                    if (0 <= depth_start < array.shape[0] and 
                        0 <= depth_end <= array.shape[0] and 
                        0 <= row_start < array.shape[1] and 
                        0 <= row_end <= array.shape[1] and 
                        0 <= col_start < array.shape[2] and 
                        0 <= col_end <= array.shape[2] and 
                        depth_start < depth_end and 
                        row_start < row_end and 
                        col_start < col_end):
                            print(f"\nSliced array:\n{array[depth_start:depth_end, row_start:row_end, col_start:col_end]}\n")
                    else:
                            print("Invalid depth, row, or column indices.")
                    
                    
            elif choice == 3:
                print("\nReturning to Main Menu...\n")
                break
                    
            else:
                print("\nInvalid choice. Please enter a number between 1 and 3.\n")
                
            print("--------------------------------------------------------------")
                
        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    indexing_slicing(np.array([21,56,34,23,90,45,67,89,12,34]))