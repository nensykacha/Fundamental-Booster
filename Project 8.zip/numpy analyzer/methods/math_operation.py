import numpy as np


def mathematical_operations(array):
    """Perform mathematical operations on the given array"""
    while True:
        try:
            
            print("\nchoose the mathematical operation to perform :\n")
            print("1. Addition")
            print("2. Subtraction")
            print("3. Multiplication")
            print("4. Division")
            print("5. Matrix Multiplication / Dot Product")
            print("6. Back To Main Menu")
            
            
            choice = int(input("Enter your choice (1-6) : "))
            
        #     if choice not in [1,2,3,4]:
        #         print("\nInvalid Choice ! Please choose a valid option (1-4)")
        #         print("--------------------------------------------------------------")
        #         return

        #     number = int(input("Enter the number to perform the operation with : "))
            
        #     print("\nOriginal Array :")
        #     print(array)
            
        #     if choice == 1:
        #         result = array + number
        #         print(f"\nResult of Addition with {number} : ")
        #         print(result)
        #         print("")
                
        #     elif choice == 2:
        #         result = array - number
        #         print(f"\nResult of Substraction with {number} : ")
        #         print(result)
        #         print("")
                
        #     elif choice == 3:
        #         result = array * number
        #         print(f"\nResult of Multiplication with {number} : ")
        #         print(result)
        #         print("")
                
        #     elif choice == 4:
        #         result = array / number
        #         print(f"\nResult of Division with {number} : ")
        #         print(result)
        #         print("")
                
        #     elif choice == 5:
        #         print("Returning to Main Menu...\n")
        #         break
                
        #     else:
        #         print("Invalid Choice ! Please choose a valid option (1-4)\n")
            
        #     print("--------------------------------------------------------------")
        
            if choice == 6:
                print("Returning to Main Menu...\n")
                break
            
            if choice not in [1,2,3,4,5]:
                print("\nInvalid Choice ! Please choose a valid option (1-6)")
                print("--------------------------------------------------------------")
                continue
            
            if choice in [1,2,3,4]:
                size = array.size
                element = input(f"Enter the same size array  elements ({size} elemetns)- separated by space : ")
                
                entered_array = np.array([x for x in element.split()], dtype=int).reshape(array.shape)
                
                print("\nOriginal Array :")
                print(array)
                print("\nEntered Array :")
                print(entered_array)
                
                if choice == 1:
                    result = array + entered_array
                    print(f"\nResult of Addition with the entered array : ")
                    print(result)
                    print("")
                
                elif choice == 2:
                    result = array - entered_array
                    print(f"\nResult of Subtraction with the entered array : ")
                    print(result)
                    print("")
                    
                elif choice == 3:
                    result = array * entered_array
                    print(f"\nResult of Multiplication with the entered array : ")
                    print(result)
                    print("")
                    
                elif choice == 4:
                    result = array / entered_array
                    print(f"\nResult of Division with the entered array : ")
                    print(result)
                    print("")
                    
            elif choice == 5:
                size = array.shape[1]  # Number of columns in the original array
                element = input("Enter Elements for second array  - separated by space : ")
                
                entered_array = np.array([x for x in element.split()], dtype=int)
                
                print("\nOriginal Array :")
                print(array)
                
                #1D
                if entered_array.ndim == 1 :
                    result = np.dot(array, entered_array)
                    print("Result of Dot Product with the entered array : ")
                    print(result)
                    print("")
                
                #2D 3D
                elif array.ndim in [2, 3]:
                    required_rows = array.shape[-1]
                    print(f"Note: Second array must have {required_rows} rows.")
                    ele = input(f"Enter elements (multiples of {required_rows}) separated by space: ")

                    rawdata = np.array([x for x in ele.split()], dtype=int)
                    enteredarray = rawdata.reshape(required_rows, -1)

                    print("\nEntered Array (reshaped for compatibility):")
                    print(enteredarray)

                    result = np.dot(array, enteredarray)
                    print(f"\nResult of Matrix Multiplication: ")
                    print(result)

                else:
                    print("Dot product/matrix multiplication for arrays with more than 3 dimensions is not supported in this demo.\n")
        except Exception:
            print("Invalid input ! Please enter valid integers for choice and number !")
        
            

if __name__ == "__main__":
    mathematical_operations()