import numpy as np 
def create_array():
    """Create a NumPy array based on user input."""
    
    try:
        
        print("\nChoose the type of array to create : ")
        print("1. 1D Array")
        print("2. 2D Array")
        print("3. 3D Array")
        
        array_choice = int(input("\nEnter Your Choice (1-3): "))
        
        if array_choice == 1:
            size = int(input("Enter the size of 1D array : "))
            values = [int(input(f"Enter Element {i+1} : "))for i in range(size)]
            return np.array(values)
            
        elif array_choice == 2:
            row = int(input("Enter Number of Rows : "))
            column = int(input("Enter Number of Columns : "))
            
            values = []
            
            for i in range(row):
                row_value=[]
                for j in range(column):
                    row_value.append(int(input(f"Enter Elements [{i}][{j}] : ")))
                values.append(row_value)
                
            return np.array(values).reshape(row,column)
            
            
        elif array_choice == 3:
            depth = int(input("Enter Depth of 3D Array : "))
            row = int(input("Enter Number of Rows : "))
            column = int(input("Enter Number of Columns : "))
            
            values = []
            
            for d in range(depth):
                depth_layer = []
                for i in range(row):
                    row_value=[]
                    for j in range(column):
                        row_value.append(int(input(f"Enter Elements [{d}][{i}][{j}] : ")))
                    depth_layer.append(row_value)
                values.append(depth_layer)
                
            return np.array(values).reshape(depth,row,column)
        
        else:
            print("\nInvalid Choice ! Please choose a valid option (1-3)")
            
        print("--------------------------------------------------------------")
    
    except Exception:
        print("\nInvalid input ! Please enter valid integers for array size and elements !")
        return None
    
    
if __name__ == "__main__":
        create_array()

