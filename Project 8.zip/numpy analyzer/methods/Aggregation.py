import numpy as np

def agregate_statics(array):
    """Perform aggregate statistics operations on the given array"""
    while True:
        try:
            
            print("\nchoose the aggregate statistics operation to perform :")
            print("1. Sum")
            print("2. Mean")
            print("3. Median")
            print("4. Standard Deviation")
            print("5. Variance")
            print("6. Back To main Menue\n")
            
            
            choice = int(input("Enter your choice (1-5) : "))
            
            print("\nOriginal Array :")
            print(array)
            
            if choice == 1:
                result = np.sum(array)
                print(f"\nSum of the array : {result}")
                
            elif choice == 2:
                result = np.mean(array)
                print(f"\nMean of the array : {result}")
                
            elif choice == 3:
                result = np.median(array)
                print(f"\nMedian of the array : {result}")
                
            elif choice == 4:
                result = np.std(array)
                print(f"\nStandard Deviation of the array : {result}")
            
            elif choice == 5:
                result = np.var(array)
                print(f"\nVariance of the array : {result}")
                
            elif choice == 6:
                print("\nReturning to main menu...")
                break
            
            else:
                print("\nInvalid Choice ! Please choose a valid option (1-5)")
            
                
            print("--------------------------------------------------------------")
            
        except Exception:
            print("\nInvalid input ! Please enter valid integers for choice !")   
        

if __name__ == "__main__":
    agregate_statics()
