import numpy as np

def search_sort_filter(array):
    """Perform search, sort and filter operations on the given array"""
    while True:
        try:
            
            print("\n choose the operation to perform :\n")
            print("1. Search for an element")
            print("2. Sort the array")
            print("3. Filter elements based on a condition")
            print("4. Back To Main Menue")
            
            choice = int(input("Enter your choice (1-4) : "))
            
            print("\nOriginal Array :")
            print(array)
            
            if choice == 1:
                #for 1D array
                if array.ndim == 1:
                    element = int(input("Enter the element to search for : "))
                    indices = np.where(array == element)[0]
                    if indices.size > 0:
                        print(f"\nElement {element} found at index/indices : {indices}")
                    else:
                        print(f"\nElement {element} not found in the array.")
                        
                #for 2D array
                elif array.ndim == 2:
                    element = int(input("Enter the element to search for : "))
                    indices = np.where(array == element)
                    if indices[0].size > 0:
                        print(f"\nElement {element} found at row/column indices : {list(zip(indices[0], indices[1]))}")
                    else:
                        print(f"\nElement {element} not found in the array.")
                        
                #for 3D array
                elif array.ndim == 3:
                    element = int(input("Enter the element to search for : "))
                    indices = np.where(array == element)
                    if indices[0].size > 0:
                        print(f"\nElement {element} found at depth/row/column indices : {list(zip(indices[0], indices[1], indices[2]))}")
                    else:
                        print(f"\nElement {element} not found in the array.")
                    
            elif choice == 2:
                #for 1D array
                if array.ndim == 1:
                    sorted_array = np.sort(array)
                    print("\nSorted Array :")
                    print(sorted_array)
                    
                #for 2D array
                elif array.ndim == 2:
                    print("\nChoose the sorting axis :")
                    print("1. Row-wise")
                    print("2. Column-wise")
                    choice_sort_axis = int(input("Enter your choice (1-2) : "))
                    if choice_sort_axis == 1:
                        sorted_array = np.sort(array, axis=1)
                    elif choice_sort_axis == 2:
                        sorted_array = np.sort(array, axis=0)
                    else:
                        print("Invalid choice ! Please choose a valid option (1-2)")
                    print("\nSorted Array :")
                    print(sorted_array)
                    
                #for 3D array
                elif array.ndim == 3:
                    print("\nChoose the sorting axis :")
                    print("1. Depth-wise")
                    print("2. Row-wise")
                    print("3. Column-wise")
                    choice_sort_axis = int(input("Enter your choice (1-3) : "))
                    if choice_sort_axis == 1:
                        sorted_array = np.sort(array, axis=0)
                        print("\nSorted Array (sorted by depth layers) :")
                        print(sorted_array)
                        
                    elif choice_sort_axis == 2:
                        sorted_array = np.sort(array, axis=1)
                        print("\nSorted Array (sorted by rows) :")
                        print(sorted_array)
                        
                    elif choice_sort_axis == 3:
                        sorted_array = np.sort(array, axis=2)
                        print("\nSorted Array (sorted by columns) :")
                        print(sorted_array)
                    else:
                        print("Invalid choice ! Please choose a valid option (1-3)")
                        
                else:
                    print("Sorting is only supported for 1D, 2D and 3D arrays.")
                
                    
            elif choice == 3:
                condition = input("Enter the condition (e.g., '> 5', '<= 10') : ")
                filtered_array = eval(f"array {condition}")
                print(f"\nElements that satisfy the condition '{condition}' :")
                print(filtered_array)
                 
            elif choice == 4:
                print("\nReturning to main menu...\n")
                break
                
            else:
                print("Invalid Choice ! Please choose a valid option (1-3)\n")
            
            print("--------------------------------------------------------------")
            
        except Exception:
            print("\nInvalid input ! Please enter valid integers for choice and element, and a valid condition !")
        
if __name__ == "__main__":
    search_sort_filter()