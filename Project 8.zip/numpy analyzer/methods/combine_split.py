import numpy as np 

def combine_split(array, axis=0):
    """Combine and split the given array along the specified axis"""
    while True:
        try:
            print("\nSelect operation to perform : ")
            print("1. Combine arrays")
            print("2. Split arrays")
            print("3. Back To Main Menue")
            
            choice = int(input("\nEnter your choice: "))
            
            if choice == 1:
                #1d array
               if array.ndim == 1:
                    number_of_arrays = int(input("Enter the number of arrays to combine: "))
                    arrays = []
                    for i in range(number_of_arrays):
                       arr = input(f"Enter array {i + 1} (comma-separated values): ")
                       arr1 = np.array([int(x.strip()) for x in arr.split(",")])
                       arrays.append(arr1)
                    array_combine = np.concatenate(arrays)
                    print("\nCombined array:")
                    print(array_combine)
                    
                #2d array
               elif array.ndim == 2:
                    number_of_arrays = int(input("Enter the number of arrays to combine: "))
                    arrays = []
                    for i in range(number_of_arrays):
                          arr = input(f"Enter array {i + 1} (comma-separated values for each row, separated by semicolons): ")
                          arr1 = np.array([[int(x.strip()) for x in row.split(",")] for row in arr.split(";")])
                          arrays.append(arr1)
                    array_combine = np.concatenate(arrays)
                    print("\nCombined array:")
                    print(array_combine)
                    
                #3d array
               elif array.ndim == 3:
                    number_of_arrays = int(input("Enter the number of arrays to combine: "))
                    arrays = []
                    for i in range(number_of_arrays):
                              arr = input(f"Enter array {i + 1} (comma-separated values for each row, separated by semicolons, and layers separated by '|'): ")
                              arr1 = np.array([[[int(x.strip()) for x in row.split(",")] for row in layer.split(";")] for layer in arr.split("|")])
                              arrays.append(arr1)
                    array_combine = np.concatenate(arrays)
                    print("\nCombined array:")
                    print(array_combine)

            #Slicing the array into multiple sub-arrays 
            elif choice == 2:
                #1d array
                if array.ndim == 1:
                    num_splits = int(input("Enter the number of splits: "))
                    sub_arrays = np.array_split(array, num_splits)
                    print("\nSplit arrays:")
                    for i, sub_array in enumerate(sub_arrays):
                        print(f"Sub-array {i + 1}: {sub_array}")
                       
                #2d array
                #Note:2d array can be split along rows (axis=0) or columns (axis=1) 
                elif array.ndim == 2:
                    num_splits = int(input("Enter the number of splits: "))
                    sub_arrays = np.array_split(array, num_splits, axis=axis)
                    print("\nSplit arrays:")
                    for i, sub_array in enumerate(sub_arrays):
                        print(f"Sub-array {i + 1}:\n{sub_array}\n")
                        
                #3d array
                #Note:3d array can be split along layers (axis=0), rows (axis=1) or columns (axis=2)
                elif array.ndim == 3:
                    depth_splits = int(input("Enter the number of splits along depth (axis=0): "))
                    row_splits = int(input("Enter the number of splits along rows (axis=1): "))
                    col_splits = int(input("Enter the number of splits along columns (axis=2): "))
                    sub_arrays = np.array_split(array, depth_splits, axis=0)
                    sub_arrays = [np.array_split(sub_array, row_splits, axis=1) for sub_array in sub_arrays]
                    sub_arrays = [[np.array_split(sub_array, col_splits, axis=2) for sub_array in row_split] for row_split in sub_arrays]
                    print("\nSplit arrays:")    
                    for i, depth_split in enumerate(sub_arrays):
                        for j, row_split in enumerate(depth_split):
                            for k, col_split in enumerate(row_split):
                                print(f"Sub-array (Depth {i + 1}, Row {j + 1}, Column {k + 1}):\n{col_split}\n")
                        
                else:
                    print("\nInvalid array dimension. Only 1D, 2D, and 3D arrays are supported.")
                    
            elif choice == 3:
                print("\nReturning to main menu...")
                break
                            
            else:
                print("\nInvalid choice. Please select 1 or 2.")
                
            print("--------------------------------------------------------------")
                
        except Exception as e:
            print(f"Error: {e}")
        

if __name__ == "__main__":
    combine_split()