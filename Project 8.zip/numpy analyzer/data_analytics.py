from methods import array_Creation as arr
from methods import indexing_slicing as ins
from methods import math_operation as mo
from methods import combine_split as cs
from methods import search_sort_filter as ssf
from methods import Aggregation as ag


class DataAnalytics:
    """Class to perform NumPy array operations"""

    def __init__(self):
        self.array = None

    def check_array(self):
        """Check if array exists"""
        if self.array is None:
            print("No array created! Please create an array first.")
            return False
        return True

    # ---------- Create Array ----------
    def create_array(self):
        self.array = arr.create_array()

        if self.array is not None:
            print("\nArray Created Successfully :)")
            print(self.array)
            print("--------------------------------------------------------------")

    # ---------- Indexing / Slicing ----------
    def indexing_slicing(self):
        if self.check_array():
            ins.indexing_slicing(self.array)

    # ---------- Mathematical Operations ----------
    def mathematical_operations(self):
        if self.check_array():
            mo.mathematical_operations(self.array)

    # ---------- Combine / Split ----------
    def combine_split(self):
        if self.check_array():
            cs.combine_split(self.array)

    # ---------- Search / Sort / Filter ----------
    def search_sort_filter(self):
        if self.check_array():
            ssf.search_sort_filter(self.array)

    # ---------- Aggregates ----------
    def aggregates(self):
        if self.check_array():
            ag.agregate_statics(self.array)
            
            