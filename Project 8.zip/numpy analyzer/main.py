from data_analytics import DataAnalytics

def main():
    """Main execution logic."""
    
    print("====================================")        
    print("Welcome to the NumPy Analyzer!")
    print("====================================\n")
    analyzer=DataAnalytics()
    
    while True:
            print("\nChoose an Option : ")
            print("1. Create a NumPy Array")
            print("2. Indexing and Slicing")
            print("3. Perform Mathematical Operations")
            print("4. Combine or split arrays")
            print("5. Search , Sort and Filter arrays")
            print("6. Compute Aggregates and Statistics")
            print("7. Exiting the NumPy Analyzer")
            
            try:
                choice = int(input("\nEnter your choice: "))

                if choice == 1:
                    analyzer.create_array()

                elif choice == 2:
                    analyzer.indexing_slicing()

                elif choice == 3:
                    analyzer.mathematical_operations()

                elif choice == 4:
                    analyzer.combine_split()

                elif choice == 5:
                    analyzer.search_sort_filter()

                elif choice == 6:
                    analyzer.aggregates()

                elif choice == 7:
                    print("\nThank you for using the NumPy Analyzer! :)")
                    break

                else:
                    print("Invalid Choice! Please select between 1-7\n")

            except Exception:
                print("Invalid input! Please enter a number.")


if __name__ == "__main__":
    main()