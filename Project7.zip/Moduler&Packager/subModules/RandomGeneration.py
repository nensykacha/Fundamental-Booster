import random, math, string

def RandomNumbers():
    """Generates random numbers based on user input."""
    try:
        count = int(input("\nHow many random numbers do you want to generate? :"))
        starting = int(input("Start range : "))
        ending = int(input("end range: "))
        
        if starting >= ending:
            starting, ending = ending, starting
        
        numbers = [random.randint(starting, ending) for _ in range(count)]
        print(f"\nGenerated Random Numbers: {numbers}")

    except ValueError:
        print("\nPlease enter valid integers.")
    except Exception as e:
        print(f"\nError: {e}")

def RandomList():
    """Generates a random list of specified length and type."""
    try:
        length = int(input("\nEnter the length: "))
        dtype = input("Enter the type of data (int/float/str): ").lower()

        if dtype == 'int':
            starting = int(input("Start range: "))
            ending = int(input("End range: "))
            random_list = [random.randint(starting, ending) for _ in range(length)]
        
        elif dtype == 'float':
            starting = float(input("Start range: "))
            ending = float(input("End range: "))
            random_list = [round(random.uniform(starting, ending), 2) for _ in range(length)]
        
        elif dtype == 'str':
            lenstr = int(input("Enter the length of each string: "))
            chars = string.ascii_letters + string.digits
            random_list = [''.join(random.choice(chars) for _ in range(lenstr)) for _ in range(length)]
        
        else:
            print("\nInvalid data type. Please choose from int, float, or str.")
            return
        
        print(f"\nGenerated Random List: {random_list}")

    except ValueError:
        print("\nPlease enter valid input.")
    except Exception as e:
        print(f"\nError: {e}")

def RandomOTP():
    """Generates a random 6-digit OTP."""

    length = int(input("\nEnter the length of OTP (default is 6): ") or 6)
    if length <= 0:
        length = abs(length)
        
    try:
        otp = ''.join([str(random.randint(0, 9)) for _ in range(length)])
        print(f"Generated OTP: {otp}")
    except Exception as e:
        print(f"\nError generating OTP: {e}")

def RandomPassword():
    """Generate a secure password."""
    try:
        length = int(input("\nEnter password length: "))
        if length <= 0:
            length = abs(length)

        chars = string.ascii_letters + string.digits + string.punctuation
        password = ''.join(random.choice(chars) for _ in range(length))
        print(f"Generated Password: {password}")

    except ValueError:
        print("\nPlease enter a valid integer for password length.")
    except Exception as e:
        print(f"\nError generating password: {e}")

def DisplayRandomMenu():
    """Displays the Random Data Generation menu."""
    try:
        while True:
            print("\nRandom Data Generation:")
            print("1. Generate Random Number")
            print("2. Generate Random List")
            print("3. Create Random Password")
            print("4. Generate Random OTP")
            print("5. Back to Main Menu")

            ch = input("Enter your choice: ")

            if ch == '1':
                RandomNumbers()
            
            elif ch == '2':
                RandomList()
            
            elif ch == '3':
                RandomPassword()
            
            elif ch == '4':
                RandomOTP()
            
            elif ch == '5':
                break
            
            else:
                print("\nInvalid choice. Please try again.")

    except Exception as e:
        print(f"\nError: {e}")


if __name__ == "__main__":
    DisplayRandomMenu()