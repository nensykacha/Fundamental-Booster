import os

def CreateFile():
    """Creates a new file."""

    fname = input("\nEnter file name: ")

    try:
        with open(fname, 'x') as f:
            pass
        print(f"\nFile '{fname}' created successfully!")

    except FileExistsError:
        print(f"File {fname} already exists. Please choose a different name.")

def WriteFile():
    """Writes data to a file."""

    fname = input("\nEnter file name: ")
    data = input("Enter data to write: ")

    try:
        with open(fname, 'w') as f:
            f.write(data)
        print(f"Data written to file '{fname}' successfully!")

    except FileNotFoundError:
        print(f"\nFile {fname} not found. Please check the name and try again.")
    except Exception as e:
        print(f"\nError writing to file: {e}")

def ReadFile():
    """Reads data from a file."""

    fname = input("\nEnter file name: ")

    try:
        with open(fname, 'r') as f:
            print("File Content:")
            print(f.read())

    except FileNotFoundError:
        print(f"\nFile {fname} not found. Please check the name and try again.")
    except Exception as e:
        print(f"\nError reading from file: {e}")

def AppendFile():
    """Appends data to an existing file."""

    fname = input("\nEnter file name: ")
    data = input("Enter data to append: ")

    try:
        with open(fname, 'a') as f:
            f.write(data + '\n')
        print(f"Data appended to file '{fname}' successfully!")

    except FileNotFoundError:
        print(f"\nFile {fname} not found. Please check the name and try again.")
    except Exception as e:
        print(f"\nError appending to file: {e}")

def DeleteFile():
    """Deletes a file."""

    fname = input("\nEnter file name to delete: ")

    try:
        os.remove(fname)
        print(f"File '{fname}' deleted successfully!")

    except FileNotFoundError:
        print(f"\nFile {fname} not found. Please check the name and try again.")
    except Exception as e:
        print(f"\nError deleting file: {e}")

def DisplayFileMenu():
    """Displays the File Operations menu."""

    try:
        while True:
            print("\nFile Operations:")
            print("1. Create a new file")
            print("2. Write to a file")
            print("3. Read from a file")
            print("4. Append to a file")
            print("5. Delete a file")
            print("6. Back to Main Menu")

            choice = input("Enter your choice: ")

            if choice == '1':
                CreateFile()
            
            elif choice == '2':
                WriteFile()
            
            elif choice == '3':
                ReadFile()
            
            elif choice == '4':
                AppendFile()
            
            elif choice == '5':
                DeleteFile()
            
            elif choice == '6':
                break
            
            else:
                print("\nInvalid choice. Please try again.")
    
    except Exception as e:
        print(f"\nError: {e}")

if __name__ == "__main__":
    DisplayFileMenu()