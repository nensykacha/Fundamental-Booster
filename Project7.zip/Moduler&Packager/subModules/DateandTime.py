from datetime import datetime
import time

def DisplayCurrentDate_Time():
    """Returns current date and time with miliseconds."""
    now = datetime.now()

    print(f"\nCurrent Date and Time: {now.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]}")
def DateTimeDifference():
    """Calculates the difference between two dates/times."""

    while True:

        print("\n1. Calculate difference between two dates")
        print("2. Calculate difference between two times")
        print("3. Back to Main Menu")

        ch = input("Enter your choice: ")

        if ch == '1':
            d1 = input("\nEnter the first date (YYYY-MM-DD): ")
            d2 = input("Enter the second date (YYYY-MM-DD): ")

            try :
                d1 = datetime.strptime(d1, "%Y-%m-%d")
                d2 = datetime.strptime(d2, "%Y-%m-%d")

                totaldays = abs((d2 - d1).days)
                totalyears = totaldays // 365

                print(f"\nDifference in days: {totaldays} days")
                print(f"Difference in years: {totalyears} years")
            
            except ValueError:
                print("\nInvalid date format. Please use YYYY-MM-DD.")
        
        elif ch == '2':
            time1 = input("\nEnter the first time (HH:MM:SS): ")
            time2 = input("Enter the second time (HH:MM:SS): ")

            try:
                t1 = datetime.strptime(time1, "%H:%M:%S")
                t2 = datetime.strptime(time2, "%H:%M:%S")

                difference = abs((t2 - t1).total_seconds())
                totalhours = int(difference // 3600)
                totalminutes = int((difference % 3600) // 60)
                totalseconds = int(difference % 60)

                print(f"\nDifference: {difference:.2f} seconds")
                print(f"Difference: {totalhours:02d}:{totalminutes:02d}:{totalseconds:02d}")
            
            except ValueError:
                print("\nInvalid time format. Please use HH:MM:SS.")
        
        elif ch == '3':
            break
        
        else:
            print("\nInvalid choice. Please try again.")

def FormatDateTime():
    """Formats date into custom format."""
    datestring = input("\nEnter a date (YYYY-MM-DD): ")

    try:
        date_obj = datetime.strptime(datestring, "%Y-%m-%d")
        formatted_date = date_obj.strftime("%B %d, %Y")
        print(f"Formatted Date: {formatted_date}")
    
    except ValueError as e:
        print(f"\nInvalid date format. Please use YYYY-MM-DD. Error: {e}")

def Stopwatch():
    """Implements a simple stopwatch."""
    input("\nPress Enter to start the stopwatch...")
    starting = time.time()
    print("Stopwatch started. Press Enter to stop.")
    input()
    ending = time.time()
    totaltime = ending - starting
    print(f"\nYour time: {totaltime:.2f} seconds")

def CountdownTimer():
    """Implements a countdown timer."""
    try:
        seconds = int(input("\nEnter the number of seconds for the countdown: "))
        print("Countdown started...")
        while seconds > 0:
            print(f"Time remaining: {seconds} seconds", end='\r')
            time.sleep(1)
            seconds -= 1
        print("Time's up!")
    
    except ValueError:
        print("Invalid input. Please enter an integer value for seconds.")

def DisplayDatetimeMenu():
    """Displays the Datetime and Time Operations menu."""

    try:
        while True:
            print("\nDatetime and Time Operations:")
            print("1. Display current date and time")
            print("2. Calculate difference between two dates/times")
            print("3. Format date into custom format")
            print("4. Stopwatch")
            print("5. Countdown Timer")
            print("6. Back to Main Menu")

            choice = input("Enter your choice: ")

            if choice == '1':
                DisplayCurrentDate_Time()
            
            elif choice == '2':
                DateTimeDifference()
            
            elif choice == '3':
                FormatDateTime()
            
            elif choice == '4':
                Stopwatch()
            
            elif choice == '5':
                CountdownTimer()
            
            elif choice == '6':
                break
            
            else:
                print("\nInvalid choice. Please try again.")

    except Exception as e:
        print(f"\nAn error occurred: {e}")

if __name__ == "__main__":
    DisplayDatetimeMenu()
