import sys
import uuid
from subModules import DateandTime as dt
from subModules import MathOperations as mth
from subModules import RandomGeneration as randg
from subModules import FileOperations as flo

def generateuuid():
    """Generates a unique identifier using uuid4."""
    try:
        unique_id = uuid.uuid4()
        print(f"Generated UUID: {unique_id}")
    except Exception as e:
        print(f"Error generating UUID: {e}")

def explore_module_attributes():
    """Dynamically explores module attributes using dir()."""
    print("\n--- Dynamic Module Exploration ---")
    print("Available modules to explore: dt, mth, sys, uuid, randg, flo")
    module_ch = input("Enter module alias to explore: ")

    try:
        if module_ch == 'dt':
            print(f"\nAttributes in Datetime_nd_Time:\n{dir(dt)}")
        elif module_ch == 'mth':
            print(f"\nAttributes in Math:\n{dir(mth)}")
        elif module_ch == 'sys':
            print(f"\nAttributes in sys:\n{dir(sys)}")
        elif module_ch == 'uuid':
            print(f"\nAttributes in uuid:\n{dir(uuid)}")
        elif module_ch == 'randg':
            print(f"\nAttributes in Random_Generation:\n{dir(randg)}")
        elif module_ch == 'flo':
            print(f"\nAttributes in File_Operations:\n{dir(flo)}")
        else:
            print("Invalid module choice. Please choose from dt, mth, sys, uuid, randg, or flo.")
            return
        
    except Exception as e:
        print(f"Error: {e}")

def main():
    """Main execution logic."""

    print("Welcome to the Multi-Utility Toolkit!")
    try:
        while True:

            print("\nMenu:")
            print("1. Datetime and Time Operations")
            print("2. Mathematical Operations")
            print("3. Random Data Generation")
            print("4. Generate Unique Identifiers (UUID)")
            print("5. File Operations (Custom Module)")
            print("6. Explore Module Attributes (dir())")
            print("7. Exit")

            ch = input("Enter your choice: ")

            if ch == '1':
                dt.DisplayDatetimeMenu()

            elif ch == '2':
                mth.DisplayMathMenu()

            elif ch == '3':
                randg.DisplayRandomMenu()

            elif ch == '4':
                generateuuid()

            elif ch == '5':
                flo.DisplayFileMenu()

            elif ch == '6':
                explore_module_attributes()

            elif ch == '7':
                print("Thank you for using the Multi-Utility Toolkit!")
                sys.exit()

    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()