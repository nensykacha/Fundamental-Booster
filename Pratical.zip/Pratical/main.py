from module.visualization import BarAnalytics, TrendAnalytics, DistributionAnalytics, FrequencyAnalytics
from module.data_summary import DataSummary
from module.expense_tracker import ExpenseTracker
import os

def main():

    tracker = ExpenseTracker()
    
    while True:
        print("\n" + "="*35)
        print("   SMART EXPENSE TRACKER MENU")
        print("="*35)
        print("1. Add New Expense")
        print("2. View Financial Summary")
        print("3. Filter by Category/Range")
        print("4. Generate Visual Reports")
        print("5. Save & Exit")
        
        choice = input("\nSelect an option (1-5): ")

        if choice == '1':
            dt = input("Enter Date (YYYY-MM-DD): ")
            try:
                am = float(input("Enter Amount: "))
                
            except ValueError:
                print("Error: Invalid amount!")
                continue
            
            ct = input("Enter Category: ")
            ds = input("Enter Description: ")
            tracker.add_expense(dt, am, ct, ds)
            
        elif choice == '2':
            if tracker.df.empty:
                print("\n[!] No data available to summarize.")
            else:
                summary_report = DataSummary(tracker.df)
                summary_report.get_summary()
            
        elif choice == '3':
            print("\nFILTER MENU: ")
            print("1. By Category")
            print("2. By Amount Range")
            print("3. By Date Range")
            
            f_type = input("Select Filter Type: ")
            if f_type == '1':
                val = input("Enter Category: ")
                tracker.filter_expenses('1', val)
                
            elif f_type == '2':
                low = input("Min Amount: ")
                high = input("Max Amount: ")
                tracker.filter_expenses('2', low, high)
                
            elif f_type == '3':
                start = input("Start Date: ")
                end = input("End Date: ")
                tracker.filter_expenses('3', start, end)
                
        elif choice == '4':
            if tracker.df.empty:
                print("\n[!] No data available for charts.")
                continue

            print("\n--- SELECT CHART ---")
            print("1. Bar Chart (Category-wise Total)")
            print("2. Line Chart (Spending Trend)")
            print("3. Pie Chart (Expense Distribution)")
            print("4. Histogram (Amount Frequency)")
            
            chh = input("Choice: ")

            chart = None
            if chh == '1': 
                chart = BarAnalytics(tracker.df)
                
            elif chh == '2': 
                chart = TrendAnalytics(tracker.df)
                
            elif chh == '3': 
                chart = DistributionAnalytics(tracker.df)
                
            elif chh == '4': 
                chart = FrequencyAnalytics(tracker.df)

            if chart:
                chart.generate()
        
        elif choice == '5':
    
            print("\n" + "─"*35)
            tracker.df.to_csv('expenses.csv', index=False)
            print("All data successfully saved to expenses.csv")
            
           
            if os.path.exists('reports'):
                print("Visual charts are stored in '/reports' folder")
            
            print("Exiting application... Goodbye!")
            print("─"*35)
            break
        
        else:
            print("Error: Invalid Choice! (1-5 only)")

if __name__ == "__main__":
    main()