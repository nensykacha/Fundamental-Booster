import pandas as pd
import numpy as np
from datetime import datetime

class DataSummary:
    def __init__(self, df):
        self.df = df

    def get_summary(self):
        """Numerical analysis with a professional report-style output."""
        if self.df.empty:
            print("\n[!] Warning: No data available to generate summary.")
            return

        # NumPy calculations
        amounts = self.df['Amount'].to_numpy()
        total = np.sum(amounts)
        average = np.mean(amounts)
        maximum = np.max(amounts)

        # Category-wise grouping
        category_totals = self.df.groupby('Category')['Amount'].sum().sort_values(ascending=False)

        # Professional Output Formatting
        print("\n" + "═"*45)
        print(" " * 12 + "FINANCIAL EXPENSE REPORT")
        print("═"*45)
        
        # Main Metrics with alignment
        print(f"{'Total Expenditure':<25}: ₹ {total:>10,.2f}")
        print(f"{'Average per Expense':<25}: ₹ {average:>10,.2f}")
        print(f"{'Highest Single Spend':<25}: ₹ {maximum:>10,.2f}")
        print(f"{'Total Transactions':<25}: {len(self.df):>12}")
        
        print("-" * 45)
        print(f"{'EXPENSES BY CATEGORY':<25}  {'AMOUNT':>15}")
        print("-" * 45)

        # Category list with proper spacing
        for category, cat_total in category_totals.items():
            print(f"  • {category:<22} : ₹ {cat_total:>12,.2f}")

        print("═"*45)
        print("Generated on: " + datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        print("═"*45)
        
def main():
    print("This module is designed to be imported and used in main.py. Please run main.py to interact with the Expense Tracker.")
    
if __name__ == "__main__":
    main()