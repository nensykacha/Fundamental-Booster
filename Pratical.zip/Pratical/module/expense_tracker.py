import pandas as pd
import numpy as np
from datetime import datetime
import os

class ExpenseTracker:
    def __init__(self, filename='expenses.csv'):
        self.filename = filename
        self.load_data()

    def load_data(self):
        if os.path.exists(self.filename):
            
            self.df = pd.read_csv(self.filename)
            
            self.df.dropna(subset=['Date', 'Category'], inplace=True)
            
            self.df['Description'] = self.df['Description'].fillna("-")
            
            self.df['Amount'] = pd.to_numeric(self.df['Amount'], errors='coerce').fillna(0)
            
            self.df['Date'] = pd.to_datetime(self.df['Date'])
            self.df['Amount'] = self.df['Amount'].astype(float)
        else:
            self.df = pd.DataFrame(columns=['Date', 'Amount', 'Category', 'Description'])
            self.df = self.df.astype({
                'Date': 'datetime64[ns]',
                'Amount': 'float64',
                'Category': 'object',
                'Description': 'object'
            })

    def add_expense(self, date, amount, category, description):
        """Improved Validation before adding data."""
        try:
            valid_date = datetime.strptime(date, '%Y-%m-%d')
            
            if not category or str(category).strip() == "":
                print("Error: Category cannot be empty!")
                return
            
            if float(amount) <= 0:
                print("Error: Amount must be positive!")
                return
            
            desc = description if description and str(description).strip() != "" else "-"

        except ValueError:
            print("Error: Use YYYY-MM-DD for Date and Number for Amount.")
            return

        new_entry = pd.DataFrame([{
            'Date': valid_date, 
            'Amount': float(amount), 
            'Category': category, 
            'Description': desc
        }])
        
        if self.df.empty:
            self.df = new_entry
        else:
            self.df = pd.concat([self.df, new_entry], ignore_index=True)
        print("Expense added successfully!")



    def filter_expenses(self, criteria, val1, val2=None):
        """Advanced filtering with Tabular Output."""
        if self.df.empty:
            print("No data to filter.")
            return

        try:
            if criteria == '1': # Category
                res = self.df[self.df['Category'].str.lower() == val1.lower()]
                
            elif criteria == '2': # Amount Range
                res = self.df[(self.df['Amount'] >= float(val1)) & (self.df['Amount'] <= float(val2))]
                
            elif criteria == '3': # Date Range
                res = self.df[(self.df['Date'] >= pd.to_datetime(val1)) & (self.df['Date'] <= pd.to_datetime(val2))]
                
            else:
                print("\n[!] Error: Invalid criteria selected!")
                return
            
        except Exception as e:
            print(f"\n[!] Input Error: Please check your values. ({e})")
            return

        if res.empty:
            print(f"\n--- No records found for this search ---")
            
        else:
            print(f"\n{'='*60}")
            print(f"SEARCH RESULTS")
            print(f"{'='*60}")
            print(res.to_string(index=False)) 
            print(f"{'='*60}")

def main():
    print("This module is designed to be imported and used in main.py. Please run main.py to interact with the Expense Tracker.")

if __name__ == "__main__":
    main()