import matplotlib.pyplot as plt
import seaborn as sns
import os

# 1. Base Class
class BaseChart:
    def __init__(self, dataframe):
        self.df = dataframe
        sns.set_style("whitegrid")
        if not os.path.exists('reports'):
            os.makedirs('reports')

    def show_plot(self, title, filename):
        plt.title(title, fontsize=15, fontweight='bold')
        plt.tight_layout()
        
        # Save chart in reports folder
        path = f"reports/{filename}.png"
        plt.savefig(path)
        print(f"[#] Chart saved successfully as {path}")
        
        plt.show()
        
# 2. Bar Chart Class
class BarAnalytics(BaseChart):
    def generate(self):
        plt.figure(figsize=(10, 6))
        data = self.df.groupby('Category')['Amount'].sum().sort_values(ascending=False)
        sns.barplot(x=data.index, y=data.values, palette='viridis', hue=data.index, legend=False)
        plt.xlabel('Category')
        plt.ylabel('Total Expenses')
        
        self.show_plot('CATEGORY-WISE TOTAL EXPENSES', 'category_bar_chart')

# 3. Line Chart Class
class TrendAnalytics(BaseChart):
    def generate(self):
        plt.figure(figsize=(10, 6))
        trend_data = self.df.groupby('Date')['Amount'].sum().reset_index()
        sns.lineplot(data=trend_data, x='Date', y='Amount', marker='o', color='royalblue', linewidth=2)
        plt.xticks(rotation=45)
        
        self.show_plot('EXPENDITURE TREND OVER TIME', 'spending_trend')

# 4. Pie Chart Class
class DistributionAnalytics(BaseChart):
    def generate(self):
        plt.figure(figsize=(8, 8))
        dist_data = self.df.groupby('Category')['Amount'].sum()
        plt.pie(dist_data, labels=dist_data.index, autopct='%1.1f%%', 
                startangle=140, colors=sns.color_palette('pastel'), radius=1.1)
        
        self.show_plot('EXPENSE DISTRIBUTION BY CATEGORY', 'expense_distribution')

# 5. Histogram Class
class FrequencyAnalytics(BaseChart):
    def generate(self):
        plt.figure(figsize=(10, 6))
        sns.histplot(self.df['Amount'], bins=15, kde=True, color='salmon')
        plt.xlabel('Expense Amount')
        
        self.show_plot('FREQUENCY OF TRANSACTION AMOUNTS', 'expense_histogram')
    
def main():
    print("This module is designed to be imported and used in main.py. Please run main.py to interact with the Expense Tracker.")
    
if __name__ == "__main__":
    main()