#  Smart Expense Tracker (AI & Data Science Project)

A professional **Python-based Data Analysis tool** built using Object-Oriented Programming (OOP) to track, analyze, and visualize personal expenses.

## Key Features
* **Modular OOP Structure**: Separate classes for Data Handling, Summary, and Charts.
* **Professional Reporting**: NumPy-powered financial summaries with perfect alignment.
* **Advanced Visualization**: 
    * **Bar Chart**: Category-wise spending analysis.
    * **Line Graph**: Daily expenditure trends.
    * **Pie Chart**: Percentage distribution of expenses.
    * **Histogram**: Frequency of transaction amounts.
* **Auto-Export**: Every chart viewed is automatically saved as a `.png` in the `/reports` folder.
* **Data Persistence**: All expenses are saved in `expenses.csv` for future use.

## Technologies Used
* **Python 3.10** *

* **Pandas**: Data manipulation & filtering.

* **NumPy**: Statistical & mathematical calculations.

* **Matplotlib & Seaborn**: High-quality data visualization.

